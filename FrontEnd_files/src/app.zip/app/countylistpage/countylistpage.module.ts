import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CountylistpageRoutingModule } from './countylistpage-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CountylistpageRoutingModule
  ],
  declarations: []
})
export class CountylistpageModule { }
