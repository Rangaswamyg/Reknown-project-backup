import { ProbabilityresultpageModule } from './probabilityresultpage.module';

describe('ProbabilityresultpageModule', () => {
  let probabilityresultpageModule: ProbabilityresultpageModule;

  beforeEach(() => {
    probabilityresultpageModule = new ProbabilityresultpageModule();
  });

  it('should create an instance', () => {
    expect(probabilityresultpageModule).toBeTruthy();
  });
});
