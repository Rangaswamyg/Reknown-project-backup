import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProbabilityresultpageRoutingModule } from './probabilityresultpage-routing.module';
import { ProbabilityresultpageComponent } from './probabilityresultpage.component';

@NgModule({
  imports: [
    CommonModule,
    ProbabilityresultpageRoutingModule
  ],
  declarations: []
})
export class ProbabilityresultpageModule { }
