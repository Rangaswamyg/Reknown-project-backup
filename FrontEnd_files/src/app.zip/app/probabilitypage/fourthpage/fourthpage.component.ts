import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray,FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProbabilityService } from '../../services/probability.service';

@Component({
  selector: 'app-fourthpage',
  templateUrl: './fourthpage.component.html',
  styleUrls: ['./fourthpage.component.css']
})
export class FourthpageComponent implements OnInit {
  form: FormGroup;
  duration=['1month','2months','3months','6months','1year','2years']
  coursespecialization:String;
  duration_of_study:String;
  certifiedcourse: String;
  duration_of_study_other: String;
 
  constructor(public _probabilityService:ProbabilityService,private formBuilder: FormBuilder, private _router: Router) {
    this.form = this.formBuilder.group({
      diplomacertification: this.formBuilder.array([ this.initdiplomacertification()]),
      othercertification: this.formBuilder.array([this.initothercertification()])
     
    });
   }

  ngOnInit() {
   
  }
  onRegisterSubmit(){
    this._probabilityService.fourthinfo = {
      diplomacertification: this.form.get('diplomacertification').value,
      // duration_of_study: this.form.get('duration_of_study').value,
      // certifiedcourse: this.form.get('certifiedcourse').value,
      othercertification: this.form.get('othercertification').value,
    
    }
    this._probabilityService.probability_input_data.push(this._probabilityService.fourthinfo);
   
     this._router.navigate(['/fifthpage']);

  }
  onchangeDropdownDuration(durObj){
    this.duration_of_study=durObj;
    console.log("dbshfds",this.duration_of_study)
  }
  onchangeDropdownDuration1(durObj){
    this.duration_of_study_other=durObj;
    console.log("dbshfds",this.duration_of_study_other)
  }

  initdiplomacertification(){
   return this.formBuilder.group({
    coursespecialization:'',
    duration_of_study:''
   });
  }
  initothercertification(){
    return this.formBuilder.group({
      certifiedcourse:'',
      duration_of_study_other:''
    });
  }
  addDiplomacertification(){
    const control =<FormArray>this.form.controls['diplomacertification'];
    control.push(this.initdiplomacertification());
  }
  removeDiplomacertification(i : number){
   const control = <FormArray>this.form.controls['diplomacertification'];
   control.removeAt(i);

  }
  addOthercertification(){
    const control =<FormArray>this.form.controls['othercertification'];
    control.push(this.initothercertification());
  }
  removeOthercertification(i : number){
    const control = <FormArray>this.form.controls['othercertification'];
    control.removeAt(i);
 
   }
  //  onMovenextPage(){
  //   this._router.navigate(['/fifthpage']);
  // }
  onBackprePage(){
    this._router.navigate(['/thirdpage']);

  }
}
