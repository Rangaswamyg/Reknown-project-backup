import { FourthpageModule } from './fourthpage.module';

describe('FourthpageModule', () => {
  let fourthpageModule: FourthpageModule;

  beforeEach(() => {
    fourthpageModule = new FourthpageModule();
  });

  it('should create an instance', () => {
    expect(fourthpageModule).toBeTruthy();
  });
});
