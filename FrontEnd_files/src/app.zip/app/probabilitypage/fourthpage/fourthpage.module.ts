import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FourthpageRoutingModule } from './fourthpage-routing.module';
import { FourthpageComponent } from './fourthpage.component';

@NgModule({
  imports: [
    CommonModule,
    FourthpageRoutingModule
  ],
  declarations: []
})
export class FourthpageModule { }
