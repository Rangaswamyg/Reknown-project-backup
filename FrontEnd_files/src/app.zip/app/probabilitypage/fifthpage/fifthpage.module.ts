import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FifthpageRoutingModule } from './fifthpage-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FifthpageRoutingModule
  ],
  declarations: []
})
export class FifthpageModule { }
