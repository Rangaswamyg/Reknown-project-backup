import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComparisonpageRoutingModule } from './comparisonpage-routing.module';


@NgModule({
  imports: [
    CommonModule,
    ComparisonpageRoutingModule
  ],
  declarations: []
})
export class ComparisonpageModule { }
