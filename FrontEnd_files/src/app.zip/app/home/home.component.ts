import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { UserService } from '../services/user.service';
import { IndexService } from '../services/index.service';

declare var $: any;
declare var jQuery: any;


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  form: FormGroup;
  showDropdown = false;
  unishowDropdown = false;
  programshowDropdown = false;
  countrieslist: Array<any> = [];
  universitylist: Array<any> = [];
  universitysearchData: any;
  programlist = [];
  constructor(private _router: Router, private formBuilder: FormBuilder, public _service: UserService, public _indexservice: IndexService) {
    this.form = this.formBuilder.group({
      search: [null],
      universitysearch: [null],
      programsearch: [null]
    });

  }


  ngOnInit() {
    $(document).ready(function ($) {
      $.fn.countTo = function (options) {
        options = options || {};

        return $(this).each(function () {
          // set options for current element
          var settings = $.extend({}, $.fn.countTo.defaults, {
            from: $(this).data('from'),
            to: $(this).data('to'),
            speed: $(this).data('speed'),
            refreshInterval: $(this).data('refresh-interval'),
            decimals: $(this).data('decimals')
          }, options);

          // how many times to update the value, and how much to increment the value on each update
          var loops = Math.ceil(settings.speed / settings.refreshInterval),
            increment = (settings.to - settings.from) / loops;

          // references & variables that will change with each update
          var self = this,
            $self = $(this),
            loopCount = 0,
            value = settings.from,
            data = $self.data('countTo') || {};

          $self.data('countTo', data);

          // if an existing interval can be found, clear it first
          if (data.interval) {
            clearInterval(data.interval);
          }
          data.interval = setInterval(updateTimer, settings.refreshInterval);

          // initialize the element with the starting value
          render(value);

          function updateTimer() {
            value += increment;
            loopCount++;

            render(value);

            if (typeof (settings.onUpdate) == 'function') {
              settings.onUpdate.call(self, value);
            }

            if (loopCount >= loops) {
              // remove the interval
              $self.removeData('countTo');
              clearInterval(data.interval);
              value = settings.to;

              if (typeof (settings.onComplete) == 'function') {
                settings.onComplete.call(self, value);
              }
            }
          }

          function render(value) {
            var formattedValue = settings.formatter.call(self, value, settings);
            $self.html(formattedValue);
          }
        });
      };

      $.fn.countTo.defaults = {
        from: 0,               // the number the element should start at
        to: 0,                 // the number the element should end at
        speed: 1000,           // how long it should take to count between the target numbers
        refreshInterval: 100,  // how often the element should be updated
        decimals: 0,           // the number of decimal places to show
        formatter: formatter,  // handler for formatting the value before rendering
        onUpdate: null,        // callback method for every time the element is updated
        onComplete: null       // callback method for when the element finishes updating
      };

      function formatter(value, settings) {
        return value.toFixed(settings.decimals);
      }
    }(jQuery));

    jQuery(function ($) {
      // custom formatting example
      $('.count-number').data('countToOptions', {
        formatter: function (value, options) {
          return value.toFixed(options.decimals).concat("+");
        }
      });

      // start all the timers
      $('.timer').each(count);

      function count(options) {
        var $this = $(this);
        options = $.extend({}, options || {}, $this.data('countToOptions') || {});
        $this.countTo(options);
      }
    });
    //  country service
    this.getcountries();
    //  university service
    this.getuniversityname();
    // program service
    this.getprogramname();

    // allitems service
  }


  // get country name in search box
  getcountries() {
    this._indexservice.countrynamefilter().subscribe(data => {
      this.countrieslist = data;
      // console.log(this.countrieslist);
    });
  }
  // get university name in search box
  getuniversityname() {
    this._indexservice.universitynamefilter().subscribe(data => {
      this.universitylist = data;
      // console.log(this.universitylist)
    });
  }
  getprogramname() {
    this.programlist = [];
    this._indexservice.courselist().subscribe(data => {
      for (var rec in data) {
        this.programlist = this.programlist.concat(new Array(data[rec].list)[0])
      }
      console.log("programmmmmmm", this.programlist);
    });
  }
  toggleDropdown() {
    //if(){
    this.showDropdown = !this.showDropdown;
    //this.showDropdown= true;
    //}else{
    // console.log("something wrong");
    //}
  }
  unitoggleDropdown() {
    this.unishowDropdown = !this.unishowDropdown;
  }
  programtoggleDropdown() {
    this.programshowDropdown = !this.programshowDropdown;
  }

  // select search box
  selectValue(details, value) {
    this.form.patchValue({ "search": value });
    this.showDropdown = false;
    var searchvalue = details;
    this.oncountryname();
    console.log(this._indexservice.countryselected_filter);
  }
  oncountryname() {
    this._indexservice.countrypageid = this.form.get('search').value + '_name';
    this._indexservice.countryselected_filter = this._indexservice.countrypageid;
  }
  universityselectValue(unidetails, value) {
    this.form.patchValue({ "universitysearch": value });
    this.unishowDropdown = false;
    var universitysearchvalue = unidetails;
    this.onuniname();
    console.log('globaluniversityvalue', this._indexservice.universitysearch_home_text);
  }
  onuniname() {
    this.universitysearchData = this.form.get('universitysearch').value;
    if (this.universitysearchData.indexOf('/') >= 0) {
      this._indexservice.universitysearch_home_text = this.universitysearchData.split('/')[0];
    } else {
      this._indexservice.universitysearch_home_text = this.universitysearchData
    }
    }
  programselectValue(value) {
    this.form.patchValue({ "programsearch": value });
    this.programshowDropdown = false;
    this.onprogramname();
    console.log('globalprogramvalue', this._indexservice.programsearchfilter);
  }
  onprogramname() {
    this._indexservice.programsearchfilter = this.form.get('programsearch').value;
  }

  // country search button
  onsearch() {
    this._indexservice.programsearchfilter = 0;
    this._indexservice.universitysearch_home_text = 0;
    this._indexservice.programlevel_checkid =0;
    this._indexservice.examscore_selected_filter = 0;
    this._router.navigate(['/filterpage/' + this._indexservice.current_page + '/' + this._indexservice.countryselected_filter + '/' + this._indexservice.programlevel_checkid + '/' + this._indexservice.programsearchfilter + '/' + this._indexservice.universitysearch_home_text + '/' + this._indexservice.examscore_selected_filter]);
  }
  onsearchprogram() {
    this._indexservice.countryselected_filter = 0;
    this._indexservice.universitysearch_home_text = 0;
    this._indexservice.programlevel_checkid =0;
    this._indexservice.examscore_selected_filter = 0;
    this._router.navigate(['/filterpage/' + this._indexservice.current_page + '/' + this._indexservice.countryselected_filter + '/' + this._indexservice.programlevel_checkid + '/' + this._indexservice.programsearchfilter + '/' + this._indexservice.universitysearch_home_text + '/' + this._indexservice.examscore_selected_filter]);

  }
  onsearchuniversity() {
    this._indexservice.countryselected_filter = 0;
    this._indexservice.programsearchfilter = 0;
    this._indexservice.programlevel_checkid =0;
    this._indexservice.examscore_selected_filter = 0;
    this._router.navigate(['/filterpage/' + this._indexservice.current_page + '/' + this._indexservice.countryselected_filter + '/' + this._indexservice.programlevel_checkid + '/' + this._indexservice.programsearchfilter + '/' + this._indexservice.universitysearch_home_text + '/' + this._indexservice.examscore_selected_filter]);
  }



  getSearchValue() {
    return this.form.value.search;
  }
  getuniversitySearchValue() {
    return this.form.value.universitysearch;
  }
  getprogramSearchValue() {
    return this.form.value.programsearch;
  }

}
