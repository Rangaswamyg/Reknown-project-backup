import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OtpverificationRoutingModule } from './otpverification-routing.module';

@NgModule({
  imports: [
    CommonModule,
    OtpverificationRoutingModule
  ],
  declarations: []
})
export class OtpverificationModule { }
