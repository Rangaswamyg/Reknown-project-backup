import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CountrypageRoutingModule } from './countrypage-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CountrypageRoutingModule
  ],
  declarations: []
})
export class CountrypageModule { }
