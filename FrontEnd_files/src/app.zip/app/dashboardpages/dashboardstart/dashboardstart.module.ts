import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardstartRoutingModule } from './dashboardstart-routing.module';

@NgModule({
  imports: [
    CommonModule,
    DashboardstartRoutingModule
  ],
  declarations: []
})
export class DashboardstartModule { }
