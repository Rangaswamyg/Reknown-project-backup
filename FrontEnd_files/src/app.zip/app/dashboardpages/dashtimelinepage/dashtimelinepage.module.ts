import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashtimelinepageRoutingModule } from './dashtimelinepage-routing.module';

@NgModule({
  imports: [
    CommonModule,
    DashtimelinepageRoutingModule
  ],
  declarations: []
})
export class DashtimelinepageModule { }
