import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardpagesRoutingModule } from './dashboardpages-routing.module';

@NgModule({
  imports: [
    CommonModule,
    DashboardpagesRoutingModule
  ],
  declarations: []
})
export class DashboardpagesModule { }
